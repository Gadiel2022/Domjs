function ventanaBienvenida() {
    alert("Bienvenido a este sitio.")
}

function ventanaDespedida() {
    alert("Lo esperamos nuevamente.")
}