document.querySelector("#boton1").addEventListener('click', () => {
    let ob1 = document.querySelector(".mensaje")
    ob1.style.backgroundColor = '#ff0'
    let ob2 = document.querySelector("#lista1")
    ob2.style.backgroundColor = '#0ff'
})