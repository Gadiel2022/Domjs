let boton1 = document.getElementById('b1')
boton1.addEventListener('click', () => {
    let boton1 = document.getElementById('b1')
    alert(boton1.getAttribute('value'))
})
let boton2 = document.getElementById('b2')
boton2.addEventListener('click', () => {
    let boton2 = document.getElementById('b2')
    alert(boton2.getAttribute('value'))
})