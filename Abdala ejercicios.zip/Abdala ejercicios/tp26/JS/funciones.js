function presionado(e) {
    alert('Coordenada x de la flecha del mouse:' + e.clientX + '\n' +
        'Coordenada y de la flecha del mouse:' + e.clientY)
}